package moleGame;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class moleGameController implements Initializable {
	@FXML
	ImageView bobi;
	@FXML
	ImageView waterDrop;
	@FXML
	ImageView gost1;
	@FXML
	ImageView gost2;
	@FXML
	ImageView gost3;
	@FXML
	ImageView gost4;
	@FXML
	ImageView gost5;
	private int SPEED1 = 10;
	private int SPEED2 = 10;
	private int SPEED3 = 10;
	private int SPEED4 = 10;
	private int SPEED5 = 10;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		bobi.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				handleImgBuby(event);
			}
		});

		Timer timer = new Timer();
		TimerTask gost1Timer = new TimerTask() {
			@Override
			public void run() {
				if (gost1.getX() <= -250) {
					gost1.setX(gost1.getX() + SPEED1);
					gost1.setRotate(0);
					SPEED1 = -SPEED1;
				}
				if (gost1.getX() >= -250) {
					gost1.setX(gost1.getX() - SPEED1);
					if (gost1.getX() >= 0) {
						gost1.setRotate(180);
						SPEED1 = -SPEED1;
					}
				} else {
					timer.cancel();// 타이머중단
				}
			}
		};
		TimerTask gost2Timer = new TimerTask() {
			@Override
			public void run() {
				if (gost2.getX() >= 110) {
					gost2.setX(gost2.getX() - SPEED2);
					gost2.setRotate(180);
					SPEED2 = -SPEED2;
				}
				if (gost2.getX() <= 110) {
					gost2.setX(gost2.getX() + SPEED2);
					if (gost2.getX() <= -150) {
						gost2.setRotate(0);
						SPEED2 = -SPEED2;
					}
				} else {
					timer.cancel();
				}
			}
		};
		TimerTask gost3Timer = new TimerTask() {
			@Override
			public void run() {
				if (gost3.getX() >= 190) {
					gost3.setX(gost3.getX() + SPEED3);
					gost3.setRotate(180);
					SPEED3 = -SPEED3;
				} else if (gost3.getX() <= 190) {
					gost3.setX(gost3.getX() - SPEED3);
					if (gost3.getX() <= -410) {
						gost3.setRotate(0);
						SPEED3 = -SPEED3;
					}

				}
			}
		};
		TimerTask gost4Timer = new TimerTask() {
			@Override
			public void run() {
				if (gost4.getX() >= 210) {
					gost4.setX(gost4.getX() - SPEED4);
					gost4.setRotate(180);
					SPEED4 = -SPEED4;
				} else if (gost4.getX() <= 210) {
					gost4.setX(gost4.getX() + SPEED4);
					if (gost4.getX() <= -60) {
						gost4.setRotate(0);
						SPEED4 = -SPEED4;
					}
				}
			}
		};
		TimerTask gost5Timer = new TimerTask() {
			@Override
			public void run() {
				if (gost5.getX() >= 40) {
					gost5.setX(gost5.getX() + SPEED5);
					gost5.setRotate(180);
					SPEED5 = -SPEED5;
				} else if (gost5.getX() <= 40) {
					gost5.setX(gost5.getX() - SPEED5);
					if (gost5.getX() <= -210) {
						gost5.setRotate(0);
						SPEED5 = -SPEED5;
					}
				}
			}
		};
		timer.schedule(gost1Timer, 10, 200);
		timer.schedule(gost2Timer, 10, 200);
		timer.schedule(gost3Timer, 10, 200);
		timer.schedule(gost4Timer, 10, 200);
		timer.schedule(gost5Timer, 10, 200);
	}

	// 좌우로 움직이기 구현완료
	public void handleImgBuby(KeyEvent event) {
		KeyCode keyCode = event.getCode();

		if (keyCode == KeyCode.LEFT) {
//			System.out.println(bobi.getX());
			if (bobi.getX() <= -50) {
				bobi.setX(-50);
				return;
			}
			bobi.setRotate(180);
			bobi.setX(bobi.getX() - 10);
			bobi.rotateProperty();
		} else if (keyCode == KeyCode.RIGHT) {
//			System.out.println(bobi.getX());
			if (bobi.getX() >= 540) {
				bobi.setX(540);
				return;
			}
			bobi.setRotate(0);
			bobi.setX(bobi.getX() + 10);
		} else if (keyCode == KeyCode.UP) {
//			System.out.println(bobi.getY());
			if (bobi.getY() <= -520) {
				bobi.setY(-520);
				return;
			}
			bobi.setY(bobi.getY() - 20);
//			buby.setY(buby.getY() + 20);
		} else if (keyCode == KeyCode.DOWN) {
//			System.out.println(bobi.getY());
			if (bobi.getY() >= -20) {
				bobi.setY(-20);
			}
			bobi.setY(bobi.getY() + 20);
		}
//		 else if (keyCode == KeyCode.SPACE) {
//			// 물거품~!
//			waterDrop.setVisible(true);
//		}
		event.consume();
	}

}
