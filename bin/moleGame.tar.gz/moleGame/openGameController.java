package moleGame;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

public class openGameController implements Initializable {

	@FXML
	StackPane stackPane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	@FXML
	public void startAction() throws IOException {
		FXMLLoader loade = new FXMLLoader(getClass().getResource("../moleGame/moleGame.fxml"));
		Parent start = loade.load();
		stackPane.getChildren().add(start);
		start.setTranslateX(((AnchorPane) start).getPrefWidth());
		Timeline timeline = new Timeline();
		KeyValue keyValue = new KeyValue(start.translateXProperty(), 0);
		KeyFrame keyFrame = new KeyFrame(Duration.millis(100), keyValue);
		timeline.getKeyFrames().add(keyFrame);
		timeline.play();
	}

}
